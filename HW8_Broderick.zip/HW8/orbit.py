import numpy as np
import matplotlib.pyplot as plt

# --- Runge-Kutta 4th Order Method ---
def rk4(state, time, tau, derivs, GM):
    k1 = tau * derivs(state, time, GM)
    k2 = tau * derivs(state + 0.5 * k1, time + 0.5 * tau, GM)
    k3 = tau * derivs(state + 0.5 * k2, time + 0.5 * tau, GM)
    k4 = tau * derivs(state + k3, time + tau, GM)
    return state + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# --- Placeholder for Adaptive RK ---
def rka(state, time, tau, adaptErr, derivs, GM):
    new_state = rk4(state, time, tau, derivs, GM)
    return new_state, time + tau, tau

# --- Derivative Function (Kepler Problem) ---
def gravrk(s, t, GM):
    r = np.array([s[0], s[1]])
    v = np.array([s[2], s[3]])
    accel = -GM * r / np.linalg.norm(r)**3
    return np.array([v[0], v[1], accel[0], accel[1]])

# --- User Inputs ---
r0 = float(input("Enter initial radial distance (AU): "))
v0 = float(input("Enter initial tangential velocity (AU/yr): "))
tau = float(input("Enter time step τ (in years): "))
nStep = 1000 # big enough for an orbit of most time steps
print("Choose numerical method:\n  1: Euler\n  2: Euler-Cromer\n  3: Runge-Kutta (RK4)\n  4: Adaptive Runge-Kutta")
NumericalMethod = int(input("Enter choice (1–4): "))

# --- Initialization ---
r = np.array([r0, 0])
v = np.array([0, v0])
state = np.array([r[0], r[1], v[0], v[1]])
GM = 4 * np.pi**2
mass = 1.0
adaptErr = 1.0e-3
time = 0.0

rplot = np.empty(nStep)
thplot = np.empty(nStep)
tplot = np.empty(nStep)
kinetic = np.empty(nStep)
potential = np.empty(nStep)

oneOrbit = False
iStep = 0

# --- Main Loop ---
while (oneOrbit != True): 
    rplot[iStep] = np.linalg.norm(r)
    thplot[iStep] = np.arctan2(r[1], r[0])
    tplot[iStep] = time
    kinetic[iStep] = 0.5 * mass * np.linalg.norm(v)**2
    potential[iStep] = -GM * mass / np.linalg.norm(r)

    conditions = [thplot[iStep - 1] < 0, thplot[iStep] >= 0]

    if(all(conditions)):
        oneOrbit = True
    
    print(iStep)
    print(kinetic[iStep], " ", potential[iStep], " ", time)

    if NumericalMethod == 1:
        # Euler
        accel = -GM * r / np.linalg.norm(r)**3
        r = r + tau * v
        v = v + tau * accel
        time += tau
    elif NumericalMethod == 2:
        # Euler-Cromer
        accel = -GM * r / np.linalg.norm(r)**3
        v = v + tau * accel
        r = r + tau * v
        time += tau
    elif NumericalMethod == 3:
        # RK4
        state = rk4(state, time, tau, gravrk, GM)
        r = state[0:2]
        v = state[2:4]
        time += tau
    else:
        # Adaptive RK
        state, time, tau = rka(state, time, tau, adaptErr, gravrk, GM)
        r = state[0:2]
        v = state[2:4]
    iStep = iStep + 1

# --- Resize Arrays to omit goofy energy valueus at the end of arrays

# --- Plot Orbit (Polar Plot) ---
plt.figure()
ax = plt.subplot(111, projection='polar')
ax.plot(thplot, rplot, '+')
ax.set_title('Distance (AU)')
ax.grid(True)
plt.show()

# --- Plot Energies ---
plt.figure()
totalE = kinetic + potential
plt.plot(tplot, kinetic, '-.', label='Kinetic')
plt.plot(tplot, potential, '--', label='Potential')
plt.plot(tplot, totalE, '-', label='Total')
plt.legend()
plt.xlabel('Time (yr)')
plt.ylabel(r'Energy ($M \cdot \mathrm{AU}^2/\mathrm{yr}^2$)')
plt.title('Comet Energy Over Time')
plt.grid(True)
plt.show()

# --- Calculate Things
period = time - tau
eccentricity = np.sqrt(1 + (2 * totalE * r**2)/((GM**2)*mass**3))
semiMajorA = 
perihelionD =

print("The period is: ", period)
print("The eccentricity is: ", eccentricity)
print("The semimajor axis is: ", semiMajorA)
print("The perihelion distance is: ", perihelionD)
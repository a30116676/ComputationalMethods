import numpy as np
import matplotlib.pyplot as plt

def bessel(arr, n): # takes in x values and n (which bessel function)
    
    if n == 0:
        a = np.sin(arr)/arr
    elif n == 1:
        a = np.sin(arr)/arr**2 - np.cos(arr)/arr
    elif n == 2:
        a = (3/arr**2 - 1)*np.sin(arr)/arr - 3*np.cos(arr)/arr**2
    else:
        print("Invalid n value")
        a = arr

    return a

meow = np.linspace(0, 20, 5000) # x values

x1 = bessel(meow, 0) # each bessel function output
x2 = bessel(meow, 1)
x3 = bessel(meow, 2)

plt.plot(meow, x1) # plotting each function output against x values
plt.plot(meow, x2)
plt.plot(meow, x3)
plt.show()
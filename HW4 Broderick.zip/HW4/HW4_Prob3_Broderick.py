import numpy as np
import matplotlib.pyplot as plt

def circle(r, x0 = 0.0, y0 = 0.0, n = 12):
    theta = np.linspace(0., 2.*np.pi, n, endpoint=True)
    x = r * np.cos(theta)
    y = r * np.sin(theta)
    return x0+x, y0+y


x, y = circle(4)

print(x)
print(y)

plt.plot(x, y)
plt.show()
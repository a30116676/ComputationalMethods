import numpy as np
import matplotlib.pyplot as plt

def diceSum (n):
    i = 0
    sum = 0
    while i < n:
        sum += np.random.random_integers(1, 6)
        i += 1
    return sum

i = 0
sums = []
while i < 10000:
    sums.extend([diceSum(2)])
    i += 1

plt.hist(sums, 11)
plt.show()

sums2 = []
i = 0
while i < 10000:
    sums2.extend([diceSum(3)])
    i += 1

plt.clf()
plt.hist(sums2, 16)
plt.show()

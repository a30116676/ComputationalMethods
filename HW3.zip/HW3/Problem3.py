import numpy as np
import matplotlib.pyplot as plt

t, d, dy = np.loadtxt("Computational Methods\HW3\data.txt",float, skiprows=5, unpack=True)

plt.plot(t, d, 'o')
plt.xlabel("time (s)")
plt.ylabel("position (cm)")
plt.errorbar(t, d, yerr=dy, fmt='o', capsize=5)
y = (3 + (1/2) * np.sin((float(np.pi))/5 * t) ) * t *(np.exp((-1/10)*t))
plt.plot(t, y, zorder=2)

plt.show()

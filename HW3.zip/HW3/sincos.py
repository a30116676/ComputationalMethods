# this program plots a function of 3x^2
import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(-np.pi, np.pi, num = 50) # creating array of x values

sin = np.sin(x)
cos = np.cos(x) # sending array of x values through function

plt.plot(x, sin, color='green', label='sin(x)')
plt.plot(x, cos, color='black', label='cos(x)')
plt.xlabel('x')
plt.ylabel('y')
plt.title('Plot of f(x) = cos(x), sin(x)')
plt.legend()
plt.show()


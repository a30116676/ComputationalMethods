# this program plots a function of 3x^2
import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(-1, 3, num = 50) # creating array of x values

y = 3*(x**2) # sending array of x values through function

plt.plot(x, y)
plt.xlabel('x')
plt.ylabel('y')
plt.title('Plot of f(x) = 3x^2')
plt.show()

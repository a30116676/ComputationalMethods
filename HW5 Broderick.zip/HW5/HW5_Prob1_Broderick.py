# 3/1/2025 This program creates and plots two regressions of velocity vs time data, one weighted and one unweighted

import numpy as np
import matplotlib.pyplot as plt

def LineFitWt(x, y, uncertainty): # returns slope and yint of a weighted linear fit to (x,y) data set
    xhat, yhat = calcHats(x, y, uncertainty)

    slope = sum((x - xhat)*y/uncertainty**2)/sum((x - xhat)*x/uncertainty**2)
    intercept = yhat - slope * xhat
    return intercept, slope

def LineFit(x, y): # Returns slope and yint of a linear fit to (x,y) data set
    xavg = x.mean()
    b = (y*(x-xavg)).sum()/(x*(x-xavg)).sum()
    yint = y.mean()-b*xavg
    return yint, b

def calcHats(x, y, uncertainty): # calculates xhat and yhat
    xhat = sum(x/sigma**2)/sum(1/sigma**2)
    yhat = sum(y/sigma**2)/sum(1/sigma**2)
    return xhat, yhat

def calcChiSquare(x, y, uncertainty, a, b): # calculates chi squared
    xhat, yhat = calcHats(x, y, uncertainty)

    chiSquared = sum(((y - a - b * x) / (sigma))**2)
    return chiSquared

def calcChiSquareR(chiSquare, n): # calculates chi squared R
    chiSquareR = (chiSquare**2)/(n - 2)
    return chiSquareR

t = np.array([2.23, 4.78, 7.21, 9.37, 11.64, 14.23, 16.55, 18.70, 21.05, 23.21]) # input data into arrays
v = np.array([139, 123, 115, 96, 62, 54, 10, -3, -13, -55])
sigma = np.array([16, 16, 4, 9, 17, 17, 12, 15, 18, 10])
n = t.size


intercept, slope = LineFitWt(t, v, sigma) # Calculate particulars using functions
intercept2, slope2 = LineFit(t, v)
chiSquared = calcChiSquare(t, v, sigma, intercept, slope)
chiSquaredR = calcChiSquareR(chiSquared, n)

plt.scatter(t, v) # plotting
plt.plot(t, slope*t + intercept)
plt.plot(t, slope2*t + intercept)
plt.xlabel("Time (t)")
plt.ylabel("Velocity (m/s)")
plt.title("Fit to y = mx + b")
plt.errorbar(t, v, yerr = sigma, color = "red")
plt.text(16, 170, "Unweighted")
plt.text(16, 160, "a1 = -10.09", color = "blue")
plt.text(16, 150, "b1 = 185.5", color = "blue")
plt.text(16, 140, "Weighted")
plt.text(16, 130, "a2 = -9.234", color = "orange")
plt.text(16, 120, "b2 = 171.9", color = "orange")
plt.text(16, 105, "ChiSquaredR = 4.211")
print("The Weighted regressions slope is not as steep as the unweighted slope because the second half of the velocity data has a higher uncertainty than the first half on average. This causes the weighted slope to be not as steep as the unweighted slope because its not considering those lower velocity values as much")
plt.show()


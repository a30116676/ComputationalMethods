# balle - Program to compute the trajectory of a baseball
#         using the Euler method.

# Set up configuration options and special features
import numpy as np
import matplotlib.pyplot as plt

def intrpf(xi,x,y):
    """Function to interpolate between data points
       using Lagrange polynomial (quadratic)
       Inputs
        x    Vector of x coordinates of data points (3 values)
        y    Vector of y coordinates of data points (3 values)
        xi   The x value where interpolation is computed
      Output
        yi   The interpolation polynomial evaluated at xi
    """

    #* Calculate yi = p(xi) using Lagrange polynomial
    yi = ( (xi-x[1])*(xi-x[2])/((x[0]-x[1])*(x[0]-x[2])) * y[0]
    + (xi-x[0])*(xi-x[2])/((x[1]-x[0])*(x[1]-x[2])) * y[1]
    + (xi-x[0])*(xi-x[1])/((x[2]-x[0])*(x[2]-x[1])) * y[2] )

    return yi

#* Initialize the data points to be fit by quadratic
x = np.empty(3)
y = np.empty(3)

#* Set initial position and velocity of the baseball
y0 = eval(input('Enter initial height (meters): '))   
r0 = np.array([0, y0])      # Initial vector position
speed = eval(input('Enter initial speed (m/s): '))
theta = eval(input('Enter initial angle (degrees): ')) 
v0 = np.array([speed * np.cos(theta*np.pi/180), 
      speed * np.sin(theta*np.pi/180)])      # Initial velocity
r = np.copy(r0)   # Set initial position 
v = np.copy(v0)   # Set initial velocity

#* Set physical parameters (mass, Cd, etc.)
Cd = 0.35      # Drag coefficient (dimensionless)
area = 4.3e-3  # Cross-sectional area of projectile (m^2)
grav = 9.81    # Gravitational acceleration (m/s^2)
mass = 0.145   # Mass of projectile (kg)
airFlag = eval(input('Air resistance? (Yes:1, No:0): '))
if airFlag == 0 :
    rho = 0.      # No air resistance
else:
    rho = 1.2     # Density of air (kg/m^3)
air_const = -0.5*Cd*rho*area/mass   # Air resistance constant

#* Loop until ball hits ground or max steps completed
tau = eval(input('Enter timestep, tau (sec): '))   # (sec)
maxstep = 1000    # Maximum number of steps
xplot = np.empty(maxstep);  yplot = np.empty(maxstep)
xNoAir = np.empty(maxstep); yNoAir = np.empty(maxstep)
for istep in range(maxstep):

    #* Record position (computed and theoretical) for plotting
    xplot[istep] = r[0]   # Record trajectory for plot
    yplot[istep] = r[1]
    t = istep*tau         # Current time
    xNoAir[istep] = r0[0] + v0[0]*t
    yNoAir[istep] = r0[1] + v0[1]*t - 0.5*grav*t**2
  
    #* Calculate the acceleration of the ball 
    accel = air_const * np.linalg.norm(v) * v   # Air resistance
    accel[1] = accel[1] - grav                  # Gravity
  
    #* Calculate the new position and velocity using Euler method
    r = r + tau*v                    # Euler step
    v = v + tau*accel     
  
    #* If ball reaches ground (y<0), break out of the loop
    if r[1] < 0 : 
        laststep = istep+1
        xplot[laststep] = r[0]  # Record last values computed
        yplot[laststep] = r[1]
        break                   # Break out of the for loop

# find corrected max range and time of flight
print(r[1])
x = [xplot[laststep - 2], xplot[laststep - 1], xplot[laststep]]
y = [yplot[laststep - 2], yplot[laststep - 1], yplot[laststep]]

xi = x[1] + (x[2] - x[0])/2
yi = intrpf(xi, x, y)
print(yi)
tratio = xi/(x[2] - x[1])


#* Print maximum range and time of flight
print ('Maximum range is', r[0], 'meters' )
print ('Time of flight is', laststep*tau , ' seconds' )
print('Corrected range is', xi, 'meters' )
print('Corrected time of flight is', laststep*tau + tratio*tau, ' seconds')

#* Graph the trajectory of the baseball
# Mark the location of the ground by a straight line
xground = np.array([0., xNoAir[laststep-1]])
yground = np.array([0., 0.])
# Plot the computed trajectory and parabolic, no-air curve
plt.plot(xplot[0:laststep+1], yplot[0:laststep+1], '+',
         xNoAir[0:laststep], yNoAir[0:laststep], '-',
         xground,yground,'r-')
plt.legend(['Euler method', 'Theory (No air)']);
plt.xlabel('Range (m)')
plt.ylabel('Height (m)')
plt.title('Projectile motion')
plt.show()